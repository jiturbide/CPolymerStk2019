# Polymer-contacts

A contact list application exercise to use polymer and custom elements.
