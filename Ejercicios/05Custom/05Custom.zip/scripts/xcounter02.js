(function(customElements){

  class XCounter extends HTMLElement {
    constructor(){
      super();
    }
    connectedCallback() {
      console.log("Conectado al DOM");
      this.innerHTML = `
          <p>Hello World</p>
      `;
    }
  } //Fin class

  customElements.define('x-counter', XCounter);

})(window.customElements);
