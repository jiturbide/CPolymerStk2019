Agenda_Polymer.md
Agenda_Polymer.md
#  Academia Polymer - Proyecto Final

* **Autor:** FGOC - Fernando González Castro
* **Emai:** f.gonzalez@softtek.com
* **Descripción:** Proyecto final del curso de Polymer 2.0
* **Fecha:** Marzo 2019


## Herramientas

* **Libreria:** Polymer 2 - Polymer CLI
* **Editor:** Atom
* **Node JS** - NPM
* **Base de datos:** Google Firebase
* **Polymer Elements**
	* dom-repeat
	* polymerfire
	* firebase-tools
	* paper-dialog
	* paper-icon-button
	* paper-toolbar
	* paper-tooltip
	* paper-button
	* iron-icons
	* iron-image
	* iron-input

## Dependencias

| Front/Back  | Archivo | Descriptción |
|--|--|--|
| Front  | main-element  | Este elemento se encarga de manejar toda la aplicación y de mostar la información obtenida de firebase, así como tambine de eliminar y actualizar contactos.
| Front  | form-element  | Este elemento se encarga de generar un paper-dialog con el formulario de registro para los datos del usuario, al mismo tiempo de mandar un customEvent con los datos validados de un contacto respectivo.

## Estructura NoSQL - Firebase

```json

/* Este archivo .json puede ser importado a firebase para generar la estructura en automatico */

{
  "contactos" : {
    "-L_5M4LPTp7aGxtTMdZt" : {
      "email" : "correo@correo.com",
      "imageUrl" : "https://picsum.photos/300/200/?random",
      "is" : "ASPA",
      "nombre" : "Allison Simpson",
      "nota" : "Texto para la nota...",
      "socialNet" : "@insagram.com",
      "telefono" : "55 3212 3945"
    },
    "-L_5WADxE7c_0gP0PQP0" : {
      "email" : "christine.price14@example.com",
      "imageUrl" : "https://picsum.photos/300/200",
      "is" : "sfs",
      "nombre" : "Christine Price",
      "nota" : "Texto para la nota",
      "socialNet" : "@social.me",
      "telefono" : "964 532 7794"
    }
  }
}
```

### Conexión a Firebase con Polymerfire

El elemento `firebase-app`es usado para inicializar y configurar la conexión con firebase:

```javascript
    <firebase-app name="agenda-polymer"
      auth-domain= "agenda-polymer.firebaseapp.com"
      database-url="https://agenda-polymer.firebaseio.com"
      api-key="AIzaSyAkr5ef0AR1D9BieDbxlz2lGMqMUPZR-mL"
      storage-bucket="agenda-polymer.appspot.com"
      messaging-sender-id="218878625439">
    </firebase-app>
```

El elemento `firebase-query` combina las propiedades dadas en opciones de para el query que generan una consulta, una peticion para filtrar, ordenar un conjunto de datos de Firebase. Los resultados de esta consulta a Firebase son sincronizados en el parametro data.

```html
    <firebase-query
      id="query"
      app-name="agenda-polymer"
      path="/contactos"
      data="{{firebaseDatos}}">
    </firebase-query>
```

## Uso de `dom-repeat`

Mediante el uso de `dom-repeat` podemos asignar los valores a un elemento del dom, haciendo uso de ''data-binding" y la "dot-notation"

```html
	<template is="dom-repeat" items="{{data}}" as="contacto">
	  <p>{{contacto.nombre}}</p>
	</template>
```
Un dato inportante que se debe asignar es el id de cada contacto,  automaticamente se puede asignar este valor de la siguente manera `contacto.$key`, por otra parte, cuando se realiza un nuevo registro, Firebase le asigna un id a los datos que el usuario manda.

## Metodos para eliminar y borrar de la base de datos.

* Para agregar un contacto a Firebase
```javascript
	this.$.query.ref.push(mi_objeto);
```
* Para eliminar un contacto de Firebase
```javascript
	this.$.query.ref.child(la_key_del_elemento).remove();
```

* Para actualizar un contacto en Firebase
```javascript
	this.$.query.ref.child(la_key_del_elemento).update({
```
## Ejecutar Proyecto


### Instalar proyecto
	```
	$ bower install o polymer install
	$ polymer serve --open
	```

###  Ejecutar aplicacion
	```
	$ polymer serve --open
	http://127.0.0.1:8081/components/polymer-agenda/
	```
Markdown 3829 bytes 471 words 130 lines Ln 122, Col 34 HTML 2916 characters 413 words 96 paragraphs
